g++ -o test test.cpp AvlTreeNode.cpp AvlTreeNode.h Comparable.h
