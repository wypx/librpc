g++ -o main main.cpp AvlTreeNode.cpp AvlTreeNode.h Comparable.h
