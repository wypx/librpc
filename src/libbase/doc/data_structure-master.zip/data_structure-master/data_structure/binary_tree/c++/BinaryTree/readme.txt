自己写的二叉树模板类，使用时只用包含头文件即可 
BinaryTree<int> tree;
