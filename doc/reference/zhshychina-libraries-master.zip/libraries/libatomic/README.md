##libatomic
This is a simple libatomic library.

Refer to atomic of ffmpeg and nginx.

