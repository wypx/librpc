/******************************************************************************
 * Copyright (C) 2014-2015
 * file:    test_libatomic.c
 * author:  gozfree <gozfree@163.com>
 * created: 2016-04-24 16:22:04
 * updated: 2016-04-24 16:22:04
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "libatomic.h"

int main(int argc, char **argv)
{
    return 0;
}
