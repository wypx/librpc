#libp2p
This is a simple p2p library.

##Dependency
* [liblog](../liblog/)
* [libgevent](../libgevent/)
* [libdict](../libdict/)
* [libskt](../libskt/)
* [libthread](../libthread/)
* [librpc](../librpc/)
* [libstun](../libstun/)
* [libptcp](../libptcp/)


