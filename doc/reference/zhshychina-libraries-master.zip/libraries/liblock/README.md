##liblock
This is a simple liblock library.

