##libhash
This is a simple hash key-value dictonary library, like libdict,
and is based on hlist from kernel list.

The key-value store type is string:string.
