#librpc
This is a simple RPC(Remote Procedure Call) library.

##Dependency
* [liblog](../liblog/)
* [libgevent](../libgevent/)
* [libdict](../libdict/)
* [libskt](../libskt/)
* [libthread](../libthread/)

##RPC server
refer to [rpcd](https://github.com/gozfree/rpcd)
