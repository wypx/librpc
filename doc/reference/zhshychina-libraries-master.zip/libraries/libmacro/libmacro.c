/******************************************************************************
 * Copyright (C) 2014-2015
 * file:    libmacro.c
 * author:  gozfree <gozfree@163.com>
 * created: 2016-06-29 11:07:41
 * updated: 2016-06-29 11:07:41
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "libmacro.h"

