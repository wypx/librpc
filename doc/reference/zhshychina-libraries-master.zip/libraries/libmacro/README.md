##libmacro
This is a simple libmacro library.

