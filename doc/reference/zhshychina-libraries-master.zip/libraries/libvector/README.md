##libvector
This is a simple vector library.


