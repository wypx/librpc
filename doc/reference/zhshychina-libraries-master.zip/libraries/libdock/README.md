##libdock
This is a simple libdock library.

