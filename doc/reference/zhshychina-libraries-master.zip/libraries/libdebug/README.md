##libdebug
This is a simple libdebug library.

NOTE: arm-gcc seems can't show backtrace, arm-g++ is ok

##How to get gcc all inner macro
$ gcc -E -dM a.c
