##libosal
This is a simple OSAL(Operating System Abstraction Layer) library.

